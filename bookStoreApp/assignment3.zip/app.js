//define angular module
'use strict'
var app;
(function(){
	'use strict'
     app = angular.module('myApp', []);

     
}
)();